package Ömer.ab_ArrayMethodlari_2DArray_Mentoring3.kahoot;

public class deneme1 {

    public static void main(String[] args) {

        int[][] array = {{1, 2}, {3,4}};

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {

                System.out.print(array[i][j] + " ");

            }
            System.out.println();

        }
    }
}





