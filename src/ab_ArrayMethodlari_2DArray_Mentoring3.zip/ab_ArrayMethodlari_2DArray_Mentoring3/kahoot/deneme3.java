package Ömer.ab_ArrayMethodlari_2DArray_Mentoring3.kahoot;

public class deneme3 {


    public static void main(String[] args) {
        //                              0               1
        int [] [] array = {{22,33},{44,55}};
//                                  0       1      0    1
        System.out.println(array[1][1]);



    }
}
