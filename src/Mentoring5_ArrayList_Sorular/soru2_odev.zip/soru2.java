package Ömer.Mentoring5_ArrayList_Sorular;

public class soru2 {
    public static void main(String[] args) {
/*
String arrayList oluşturun. 5 elemandan oluşturun.

1.   elemanEkle isminde bir method oluşturun
 ve bana String Arraylist döndürsün. Parametre olarak String arraylist.
Scanner kullanarak  5 özel isim girin ve bu isimler bu methodda ArrayListe eklensin. (Hüseyin, Ömer,Nalan vb.)


2.    sil    isminde void bir method çağırın.
 Parametresi String ArrayList olsun.
ArrayListimin içindeki elemanlar "l" (en az bir eleman  "küçük L"  harfine sahip olması koşul için yeterlidir.) harfine sahipse, bütün arrayList temizlensin. (silinsin, boşaltılsın.)

3.    listeBosMu   adında void bir method oluşturun.
ve  parametresi    String  ArrayList olsun.
Listenin boş olup olmadıgını check etsin. Liste boş ise true,  boş değil ise false döndürsün.  (ArrayList methodu kullanın.)
Liste boş ise  listeyi yazdırıp check edin.


Konsoldaki görüntü bunun gibi olmalı(Kendi değerlerinizi girerek deneyin)

1. elemanı giriniz:  ömer
2. elemanı giriniz:  hüseyin
3. elemanı giriniz:  nalan
4. elemanı giriniz:  sevket
5. elemanı giriniz:  osman
[ömer, hüseyin, nalan, sevket, osman]

L harfi bulunanlar : nalan
Liste boşaltılmıştır...

ArrayList boş mu ? =    true
Arraylist'im boştur =   []

 */


    }
}
